from tkinter import *
import openpyxl
from classes.manage import *
class Dscore(Manage):
    #window = Tk()
    #window.title('Score Manager')
    path = "db/football.xlsx"
    wb = openpyxl.load_workbook(path)
    objWb = Manage(wb)
    def __init__(self):
        self.win = 'A'
    def DDscore(self):
        self.window = Tk()
        self.window.title('Score Table')
        super().__init__(Dscore.wb)
        self.header = Frame(self.window, width = 400, height = 20)
        self.frm1 = Frame(self.window)
        self.sandwitch = Frame(self.window, width = 400, height = 20)
        self.body = Frame(self.window, width = 400, height = 50)
        self.body2 = Frame(self.window, width = 400, height = 50)
        self.body2_1 = Frame(self.window, width = 400, height = 30)
        self.body3 = Frame(self.window, width = 400, height = 50)
        self.footer = Frame(self.window, width = 550, height = 50)
        self.drpdn1 = StringVar()
        self.drpdn2 = StringVar()
        self.score1 = IntVar()
        self.score2 = IntVar()
        self.tabcont = StringVar()
        sht = super().chooseSheet("clubs")
        self.choice1 = super().listColclub(2)
        self.drpdn2.set('Select Club')
        self.drpdn1.set('Select Club')





        #displays
        self.msg = Label(self.frm1, text = '', font = 'Times 10 bold')
        self.bakbtn = Button(self.frm1, text = 'return to main menu', command = self.GOBACK)
        self.label1 = Label(self.frm1, text = 'Score Manager', font = 'Times 15 bold')
        self.sclub1 = OptionMenu(self.body, self.drpdn1, *self.choice1)
        self.ent1 = Entry(self.body, textvariable = self.score1, width = 10)
        self.ent2 = Entry(self.body, textvariable = self.score2, width = 10)
        self.sclub2 = OptionMenu(self.body, self.drpdn2, *self.choice1)
        self.but1 = Button(self.body2, text = 'Add', font = 'Times 10 bold', width = 8, command = self.But1)
        
        



        #packing
        self.header.pack()
        self.frm1.pack()
        self.sandwitch.pack()
        self.body.pack()
        #button
        self.body2.pack()
        self.but1.pack()
        self.body2_1.pack()

        
        self.msg.pack()
        self.bakbtn.pack()
        self.label1.pack()
        self.sclub1.grid(row = 1, column = 1)
        self.ent1.grid(row = 1, column = 2)
        self.ent2.grid(row = 1, column = 3)
        self.sclub2.grid(row = 1, column = 4)

        
        self.body3.pack()
        #for i in range(1, 10):
        self.footer.pack()
        super().chooseSheet("score_table")
        sheets = self.wb["score_table"]
        maxRow = sheets.max_row
        maxCol = sheets.max_column
        
        for row in range(1,maxRow):
           for col in range(1,maxCol):
               value = sheets.cell(row = row, column = col).value
               Label(self.body3, text = value, fg = "black",bg="white").grid(row = row, column = col)
               
              
        #for i in range(1, 10):
            #self.ent3 = Entry(self.body3, width = 8).grid(row = 5, column = i)

        
    def But1(self):
        lst1 = []
        lst2 = []
        if(self.drpdn1.get() == 'Select Club' or self.drpdn2.get() == 'Select Club'):
            self.msg['text'] = 'Please select two clubs!'
        elif(self.drpdn1.get() == self.drpdn2.get()):
            self.msg['text'] = 'Please select different clubs!'
        else:
            self.msg['text'] = 'Score added succesfully!'
            lst1 = [self.drpdn1.get(), self.score1.get()]
            lst2 = [self.drpdn2.get(), self.score2.get()]
            spl1 = lst1[0].split()
            spl2 = lst2[0].split()
            club1 = [int(spl1[0]), int(lst1[1])]
            club2 = [int(spl2[0]), int(lst2[1])]
            super().addScore(club1,club2)
    def GOBACK(self):
        self.window.destroy()
        import Caller4
        



