from tkinter import *
from players import *

class J():
    def __init__(s):
        s.what = Tk()
        s.what.destroy()
        super().__init__()
        Cll().cl()
    def YEAH(s):
        s.what.destroy()
        w.destroy()
        super().__init__()
        

class K(J):
    def __init__(self):
        self.window = Tk()
        self.window.title('Welcome Page')
        
    #def L(self):
        self.tkvar = StringVar()
        self.choices = {'hi', 'how', 'try'}
        self.tkvar.set('try')
        self.frm = Frame(self.window)
        self.frm.pack()
        self.opt = OptionMenu(self.frm, self.tkvar, *self.choices)
        self.opt.pack()
        self.btn = Button(self.frm, text = 'Hi', command = self.CMD)
        self.btn.pack()
    def CMD(self):
        if(self.tkvar.get() == 'try'):
            pass
        elif(self.tkvar.get() == 'hi'):
            print('hi')
            self.window.destroy()
            J()
        else:
            pass


        
K()
