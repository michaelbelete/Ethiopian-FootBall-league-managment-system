from tkinter import *
from classes.manage import *
import openpyxl

class Clbs(Manage):
    path = "db/football.xlsx"
    wb = openpyxl.load_workbook(path)
    objWb = Manage(wb)
    def __init__(self):
        self.window = Tk()
        super().__init__(Clbs.wb)
    def Clubs(self):
        window = self.window
        window.title('Clubs Management')
        self.header = Frame(window, width = 400, height = 50)
        self.head = Frame(window, width = 400, height = 30)
        self.head.pack()
        self.hdstring = Frame(window)
        self.hdstring.pack()
        self.entrtxt = Frame(window)
        self.entrtxt.pack()
        self.header.pack()
        self.btnfr = Frame(window)
        self.btnfr.pack()
        self.tbl = Frame(window)
        self.tbl.pack()
        self.footer = Frame (window, width = 400, height = 50)
        self.cname = StringVar()



        #flakdjf
        self.lbl0 = Label(self.hdstring, text = 'Manage Club', font = 'Times 15 bold')
        self.lbl11 = Label(self.header, text = '')
        self.lbl1 = Label(self.entrtxt, text = 'Enter Club Name: ', font = 'Times 10 bold')
        self.ent1 = Entry(self.header, textvariable = self.cname)
        self.bu1 = Button(self.btnfr, text = 'Add', font = 'Times 10 bold', command = self.AddCoach)
        self.btn = Label(self.header, text = '')
        self.lbl2 = Label(self.head, text = '', font = 'Times 10 bold')
        self.btn3 = Button(self.head, text = 'return to main menu', command = self.GOBACK)
        

        #display
        super().chooseSheet("clubs")
        sheets = self.wb["clubs"]
        maxRow = sheets.max_row
        maxCol = sheets.max_column
        
        for row in range(1,maxRow):
            for col in range(1,maxCol):
                value = sheets.cell(row = row, column = col).value
                Label(self.tbl, text = value, fg = "black",bg="white").grid(row = row, column = col)
                

        #packing
        self.lbl0.pack()
        self.lbl11.grid(row = 1, column = 1)
        self.lbl1.pack()
        self.ent1.grid(row = 3, column = 2)
        self.bu1.pack()
        #self.btn.grid(row = 3, column = 1)
        self.lbl2.pack()
        self.ent1.grid(row = 1, column = 1)
        self.footer.pack()
        self.btn3.pack()
    def AddCoach(self):
        lst1 = []
        if(self.cname.get() == ''):
            self.lbl2['text'] = 'Please enter club name!'
        else:
            lst1.append(self.cname.get())
            self.lbl2['text'] = 'Coach added succesfully!'
            print(lst1)
            super().chooseSheet("clubs")
            super().addValue(lst1)
    def GOBACK(self):
        self.window.destroy()
        import Caller1

#C().Clubs()
