from tkinter import *
from classes.manage import *
import openpyxl
class A(Manage):
    path = "db/football.xlsx"
    wb = openpyxl.load_workbook(path)
    objWb = Manage(wb)
    def __init__(self):
        self.window = Tk()
        super().__init__(A.wb)
    def Name(self):
        window = self.window
        window.title('Manage Players')
        header = Frame(window, width = 500, height = 200)
        header.pack()
        #self.table = Frame(window, width = 500, height = 100)
        self.footer = Frame(window, width = 500, height = 50)
        self.frame = Frame(window)
        self.butframe = Frame(window)
        self.butframed = Frame(window, height = 20)
        self.table = Frame(window)
      


        #self.table.pack()
        self.frame.pack()
        self.butframe.pack()
        self.butframed.pack()
        self.pname = StringVar()
        self.page = IntVar()
        self.pheight = DoubleVar()
        self.pweight = DoubleVar()
        self.pnationality = StringVar()
        self.pclub = StringVar()
        self.pfee = IntVar()
        self.pfoot = StringVar()
        self.tkvar = StringVar()
        sht = super().chooseSheet("clubs")
        self.choices = super().listCol(2)
        self.tkvar.set('Select Club')
        self.butwindow = Frame(window)
        self.padabove = Label(header, text = '', font = 'Times 11 bold')
        self.paddown = Label(header, text = '')
        backbut = Button(header, text = 'return to main menu', command = self.GOBACK)
        backbut.pack()
        welcometext = Label(header, text = 'Manage Players', font = 'Times 15 bold')
        self.padabove.pack()
        backbut.pack()
        welcometext.pack()
        self.paddown.pack()
        #the frm displays
        entpname = Label(self.frame, text = 'Full Name: ')
        pname = Entry(self.frame, textvariable = self.pname)
        entpage = Label(self.frame, text = 'Player Age: ')
        page = Entry(self.frame, textvariable = self.page)
        entpheight = Label(self.frame, text = 'Player Height: ')
        pheight = Entry(self.frame, textvariable = self.pheight)
        entpweight = Label(self.frame, text = 'Player Weight: ')
        pweight = Entry(self.frame, textvariable = self.pweight)
        entpnationality = Label(self.frame, text = 'Player Nationality: ')
        pnationality = Entry(self.frame, textvariable = self.pnationality)
        entpclub = Label(self.frame, text = 'Player Club: ')
        pclub = Entry(self.frame, textvariable = self.pclub)
        entpfee = Label(self.frame, text = 'Monthly Fee: ')
        pfee = Entry(self.frame, textvariable = self.pfee)
        entpfoot = Label(self.frame, text = 'Prefered Foot: ')
        pfoot = Entry(self.frame, textvariable = self.pfoot)
        popclub = OptionMenu(self.frame, self.tkvar, *self.choices)
        butabove = Label(self.frame, text = '')
        addbut = Button(self.butframe,text = 'Add Player', font = 'Times 10 bold', command = self.C, width = 15)
        
        
        #the frm positions
        entpname.grid(row = 1, column = 1)
        pname.grid(row = 1, column = 2)
        entpage.grid(row = 1, column = 3)
        page.grid(row = 1, column = 4)
        entpheight.grid(row = 2, column = 1)
        pheight.grid(row = 2, column = 2)
        entpweight.grid(row = 2, column = 3)
        pweight.grid(row = 2, column = 4)
        entpnationality.grid(row = 3, column = 1)
        pnationality.grid(row = 3, column = 2)
        entpclub.grid(row = 3, column = 3)
        #pclub.grid(row = 3, column = 4)
        entpfee.grid(row = 4, column = 1)
        pfee.grid(row = 4, column = 2)
        entpfoot.grid(row = 4, column = 3)
        pfoot.grid(row = 4, column = 4)
        popclub.grid(row = 3, column = 4)
        butabove.grid(row = 5, column = 1)
        self.table.pack()
        self.butwindow.pack()
        #self.padabove.pack()
        #self.paddown.pack()

        ##################################################################
        addbut.pack()
        val = StringVar(value = self.tkvar.get())
        #the table displays
        tablelabel1 = Label(self.table, text = 'Players', font = 'Times 10 bold')
        tablelabel1.grid(row = 0, column = 0)
        
        #display
        super().chooseSheet("players")
        sheets = self.wb["players"]
        maxRow = sheets.max_row
        maxCol = sheets.max_column
        
        for row in range(1,maxRow):
            for col in range(1,maxCol):
                value = sheets.cell(row = row, column = col).value
                Label(self.butwindow, text = value, fg = "black",bg="white").grid(row = row, column = col)
        #self.table.pack()
        self.footer.pack()
        window.mainloop()
    def C(self):
        lst1 = [self.pname.get(), self.page.get(), self.pheight.get(), self.pweight.get(), self.pnationality.get(), self.tkvar.get(), self.pfoot.get(), self.pfee.get()]
        lst2 = []
        su = 0
        for i in lst1:
            if(self.tkvar.get() == 'Select Club'):
                print('An entry can\'t be empty!')
                self.padabove['text'] = 'An entry can\'t be empty!'
                su += 1
                break
            if(str(i) == ''):
                print('An entry can\'t be empty!')
                self.padabove['text'] = 'An entry can\'t be empty!'
                su += 1
                break
            else:
                lst2.append(i)
                self.padabove['text'] = 'Player added succesfully!'
        if(su <= 0):
            print(lst2)
            super().chooseSheet("players")
            super().addValue(lst2)            
        else:
            pass
    def GOBACK(self):
        self.window.destroy()
        import Caller3
    def UP(self):
        pass       
#A().Name()
class Clspl(A):
    def __init__(self, a = 1):
        self.a = a
    def cl(self):
        A().Name()
#Cll().cl()
