class Manage:
    def __init__(self,wb):
        self.__wb = wb
        self.__sheet = self.__wb.active
    def chooseSheet(self, sheet_name):
        self.__sheet = self.__wb[sheet_name]
    def addValue(self,lst):     
        self.__m_row = self.__sheet.max_row
        self.__m_col = self.__sheet.max_column
        try:
          countLst = len(lst)
          for i in range(0,countLst+1):
               col = i + 1
               cell = self.__sheet.cell(row = self.__m_row+1, column = col)
               if col == 1:
                    cell.value = self.__m_row
               else:
                    cell.value = lst[i-1]     
          self.__wb.save("db/football.xlsx")
        except PermissionError:
          print("Can't write on file. Please, close the file if it is open")
    def addRow(self,lst,row_num):     
        try:
          countLst = len(lst)
          for i in range(0,countLst+1):
               col = i + 1
               cell = self.__sheet.cell(row = row_num+1, column = col)
               if col == 1:
                    cell.value = row_num + 1
               else:
                    cell.value = lst[i-1]     
          self.__wb.save("db/football.xlsx")
        except PermissionError:
          print("Can't write on file. Please, close the file if it is open")
    def addScore(self,club1,club2):
        self.chooseSheet("score_table")
        self.__m_row = self.__sheet.max_row
        self.__m_col = self.__sheet.max_column

        club1_id = self.__sheet.cell(row = club1[0] , column = 1)
        club2_id = self.__sheet.cell(row = club2[0] , column = 1)

        if(club1[0] == "" or club2[0] == ""):
            return "Empty clubs please check the club you selected"
        elif club1[0] == club2[0]:
            return "The team you selectd are same"
        else:
            org_lst_club1 = []
            for col in range(2,self.__m_col+1):
                org_lst_club1.append(self.__sheet.cell(row = club1[0]+1 , column = col).value)
                
            org_lst_club2 = []
            for col in range(2,self.__m_col+1):
                org_lst_club2.append(self.__sheet.cell(row = club2[0]+1 , column = col).value)
            print(org_lst_club1)  
            print(org_lst_club2) 

            club_name1 = org_lst_club1[0]
            point1 = int(org_lst_club1[1])
            win1 = int(org_lst_club1[2])
            lost1 = int(org_lst_club1[3])
            scored1 = int(org_lst_club1[4])
            concided1 = int(org_lst_club1[5])

            club_name2 = org_lst_club2[0]
            point2 = int(org_lst_club2[1])
            win2 = int(org_lst_club2[2])
            lost2 = int(org_lst_club2[3])
            scored2 = int(org_lst_club2[4])
            concided2 = int(org_lst_club2[5])

            club1_scored = int(club1[1])
            club2_scored = int(club2[1])

            
            goal_differ1 = (scored1+club1_scored) - (scored2 - concided2)
            
            goal_differ2 = (scored2+club2_scored) - (concided2-club2_scored)
            if int(club1[1]) == int(club2[1]):
                self.__club1_lst = [club_name1,point1+1,win1,lost1,scored1+club1_scored,concided1-club2_scored,goal_differ1]
                self.__club2_lst = [club_name2,point2+1,win2,lost2,scored2+club2_scored,concided2-club2_scored,goal_differ2]
            elif int(club1[1]) > int(club2[1]):
                self.__club1_lst = [club_name1,point1+3,win1+1,lost1,scored1+club1_scored,concided1-club2_scored,goal_differ1]
                self.__club2_lst = [club_name2,point2,win2,lost2+1,scored2+club2_scored,concided2-club2_scored,goal_differ2]
            else:
                self.__club1_lst = [club_name1,point1,win1,lost1+1,scored1+club1_scored,concided1-club2_scored,goal_differ1]
                self.__club2_lst = [club_name2,point2+3,win2+1,lost2,scored2+club2_scored,concided2-club2_scored,goal_differ2]
            self.addRow(self.__club1_lst,club1[0])
            self.addRow(self.__club2_lst,club2[0])   
    def addClub(self,lst):
        self.chooseSheet("clubs")
        self.addValue(lst)        
        self.chooseSheet("score_table")
        clubs = [lst[0],0,0,0,0,0,0]
        self.addValue(clubs)
    def listCol(self,cols):        
        self.__m_row = self.__sheet.max_row
        self.__m_col = self.__sheet.max_column
        value = list()
        for col in range(1,self.__m_row+1):
            if col == 1:
                value.append("Select value")
            else:
                value.append(self.__sheet.cell(row=col,column=cols).value)
        return value
    def listColclub(self,cols):        
        self.__m_row = self.__sheet.max_row
        self.__m_col = self.__sheet.max_column
        value = list()
        for col in range(1,self.__m_row+1):
            if col == 1:
                value.append("Select value")
            else:
                ids = self.__sheet.cell(row=col,column=cols-1).value
                v = self.__sheet.cell(row=col,column=cols).value
                ap = str(ids) +" "+ str(v)
                value.append(ap)
        return value

    
        
