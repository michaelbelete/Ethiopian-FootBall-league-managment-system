from tkinter import *
from classes.manage import *
import openpyxl
class B(Manage):
    path = "db/football.xlsx"
    wb = openpyxl.load_workbook(path)
    objWb = Manage(wb)
    def __init__(self):
        self.window = Tk()
        super().__init__(B.wb)
    def Coach(self):
        window = self.window
        window.title('Manage Coachs')
        self.header = Frame(window, width = 500, height = 30)
        self.header.pack()
        self.footer = Frame(window, height = 30)
        self.body = Frame(window, width = 500, height = 300)
        self.body.pack()
        self.but = Frame(window)
        self.but.pack()
        self.ft = Frame(window, width = 350, height = 2)
        self.ft.pack()
        self.table = Frame(window, width = 500, height = 300)
        self.table.pack()

        #assign
        self.cvname = StringVar()
        self.cvclub = StringVar()
        self.cvsalary = IntVar()
        

        #coach
        self.cheader = Label(self.header, text = '')
        self.cfooter = Label(self.header, text = '')
        self.coachlabel1 = Label(self.header, text = 'Manage Coachs', font = 'Times 15 bold')
        self.cname = Label(self.body, text = 'Full Name: ')
        self.centname = Entry(self.body, textvariable = self.cvname)
        self.cclub = Label(self.body, text = 'Coach\'s Club: ')
        self.centclub = Entry(self.body, textvariable = self.cvclub)
        self.csalary = Label(self.body, text = 'Coach Salary: ')
        self.centsalary = Entry(self.body, textvariable = self.cvsalary)

        self.cbutton1 = Button(self.but, text = 'Add', font = 'Times 10 bold', width = 12, command = self.Add)


        '''self.changedlabelheadern = Label(self.table, text = 'Coach Name', font = 'Times 10 bold')
        self.changedlabelheaderc = Label(self.table, text = 'Coach\'s Club', font = 'Times 10 bold')
        self.changedlabelheaders = Label(self.table, text = 'Coach\'s Salary', font = 'Times 10 bold')
        self.chlabeln = Entry(self.table, text = '', font = 'Times 10 bold', width = 10)
        self.chlabelc = Entry(self.table, text = '', font = 'Times 10 bold', width = 10)
        self.chlabels = Entry(self.table, text = '', font = 'Times 10 bold', width = 10)
'''
        super().chooseSheet("coachs")
        sheets = self.wb["coachs"]
        maxRow = sheets.max_row
        maxCol = sheets.max_column
        
        for row in range(1,maxRow):
            for col in range(1,maxCol):
                value = sheets.cell(row = row, column = col).value
                Label(self.table, text = value, fg = "black",bg="white").grid(row = row, column = col)

        
        self.space = Label(self.body, text = '\t')
        self.changedlabel = Label(self.cheader, text = '', font = 'Times 10 bold')
        self.chanbtn = Button(self.cheader, text = 'return to main menu', command = self.GOBACK)

        


        #coach posiions
        self.cheader.pack()
        self.coachlabel1.pack()
        self.cfooter.pack()
        self.cname.grid(row = 2, column = 1)
        self.centname.grid(row = 2, column = 2)
        self.cclub.grid(row = 3, column = 1)
        self.centclub.grid(row = 3, column = 2)
        self.csalary.grid(row = 4, column = 1)
        self.centsalary.grid(row = 4, column = 2)
        self.cbutton1.pack()
        #self.changedlabelheadern.grid(row = 6, column = 1)
        #self.changedlabelheaderc.grid(row = 6, column = 2)
        #self.changedlabelheaders.grid(row = 6, column = 3)
        #self.chlabeln.grid(row = 7, column = 1)
        #self.chlabelc.grid(row = 7, column = 2)
        #self.chlabels.grid(row = 7, column = 3)
        self.space.grid(row = 8, column = 1)
        self.changedlabel.pack()
        self.chanbtn.pack()


        self.footer.pack()
        window.mainloop()

    def Add(self):
        lst1 = [self.cvname.get(), self.cvclub.get(), self.cvsalary.get()]
        lst2 = []
        su = 0
        for i in lst1:
            if(i == ''):
                su += 1
                print('An Entry can\'t be empty!')
                self.changedlabel['text'] = 'An Entry can\'t be empty!'
                break
            else:
                lst2.append(i)
        if(su == 0):
            print(lst2)
            super().chooseSheet("coachs")
            super().addValue(lst2)
            #self.chlabeln['text'] = lst1[0]
            #self.chlabelc['text'] = lst1[1]
            #self.chlabels['text'] = lst1[2]
            self.changedlabel['text'] = 'Succesfully Added!'
        else:
            pass
    def GOBACK(self):
        self.window.destroy()
        import Caller2
#B().Coach()
class Cll(B):
    def __init__(self, a = 1):
        self.a = a
    def cl(self):
        B().Coach()
