from tkinter import *
from players import *
from Coach import *
from Clubs import *
from Score_Table import *

class J(Clspl):
    def __init__(s):
        super().__init__()
        super().cl()
        
class K(Cll):
    def __init__(s):
        super().__init__()
        super().cl()
class L(Clbs):
    def __init__(s):
        super().__init__()
        super().Clubs()
class ST(Dscore):
    def __init__(s):
        super().__init__()
        super().DDscore()


class Call(J, K, L):
    def __init__(self):
    
        
        self.win = Tk()
        self.win.title('Home Page')
    def Call1(self):
        self.headerup = Frame(self.win, width = 400, height = 20)
        self.headerbody = Frame(self.win, width = 400, height = 20)
        self.headerdown = Frame(self.win, width = 400, height = 20)
        self.tkvar = StringVar()
        self.choices = {'Select Window', 'Manage Players', 'Manage Coachs', 'Manage Clubs', 'Score Table'}
        self.tkvar.set('Select Window')
        self.grpname = Frame(self.win)


        self.lbl0 = Label(self.headerup, text = '', font = 'Times 10 bold')
        self.projectname = Label(self.headerup, text = 'Ethiopian Football League Management \nSystem\n', font = 'Times 20 bold')
        self.groupname = Label(self.grpname, text = 'Group Name: \nGroup Members: \n1: Dawit Bezabih \n2: Haben Tesfay \n3: Kaleb Fedadu \n4: Maria G/Medhin \n5: Michael Belete')
        self.groupid = Label(self.grpname, text = 'Crypt\nID:\n ATR/8263/11\nETR/0140/11\nATR/6065/11\nATR/1627/11\nATR/5388/11')
        self.lbl1 = Label(self.headerup, text = 'Welcome, choose what you want to do :)', font = 'Times 15 bold')
        
        self.opt = OptionMenu(self.headerbody, self.tkvar, *self.choices)
        self.opt.pack()
        
        self.btn1 = Button(self.headerbody, text = 'Open', command = self.MngPl)
    
        

        #frame packs
        self.headerup.pack()
        self.headerbody.pack()
        self.headerdown.pack()
        self.grpname.pack()
        
                               

        #other packs
        self.lbl0.pack()
        self.projectname.pack()
        self.lbl1.pack()
        
        self.btn1.pack()
        self.groupname.grid(row = 1, column = 1)
        self.groupid.grid(row = 1, column = 2)
        


        self.win.mainloop()

    def MngPl(self):
        if(self.tkvar.get() == 'Select Window'):
            self.lbl0['text'] = 'Please select window!'
            print('Please select!')
        elif(self.tkvar.get() == 'Manage Players'):
            self.win.destroy()
            J()
        elif(self.tkvar.get() == 'Manage Coachs'):
            self.win.destroy()
            K()
        elif(self.tkvar.get() == 'Manage Clubs'):
            self.win.destroy()
            L()
        elif(self.tkvar.get() == 'Score Table'):
            self.win.destroy()
            ST()



        
Call().Call1()
